package br.com.fiap.beer.service;

import br.com.fiap.beer.entity.Brewery;
import br.com.fiap.beer.repository.BreweryRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BreweryService {

    private final BreweryRepository breweryRepository;

    public BreweryService(BreweryRepository breweryRepository) {
        this.breweryRepository = breweryRepository;
    }

    @Cacheable("breweries")
    public List<Brewery> getAll() {
        return breweryRepository.findAll();
    }

    @Cacheable(value = "breweryById", key = "#id")
    public Brewery getById(Long id) {
        return breweryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Brewery not found"));
    }

    @CacheEvict(value = {"breweries", "breweryById"}, allEntries = true)
    public Brewery create(Brewery brewery) {
        return breweryRepository.save(brewery);
    }

    @CacheEvict(value = {"breweries", "breweryById"}, allEntries = true)
    public Brewery update(Long id, Brewery brewery) {
        Brewery existing = getById(id);

        existing.setName(brewery.getName());
        existing.setCountry(brewery.getCountry());

        return breweryRepository.save(existing);
    }

    @CacheEvict(value = {"breweries", "breweryById"}, allEntries = true)
    public void delete(Long id) {
        breweryRepository.deleteById(id);
    }
}
