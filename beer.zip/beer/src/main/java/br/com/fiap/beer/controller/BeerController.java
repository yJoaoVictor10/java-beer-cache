package br.com.fiap.beer.controller;

import br.com.fiap.beer.entity.Beer;
import br.com.fiap.beer.repository.BeerRepository;
import br.com.fiap.beer.service.BeerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/beers")
@Tag(name = "Beers", description = "Gerenciamento de cervejas")
public class BeerController {

    private final BeerService beerService;

    public BeerController(BeerService beerService) {
        this.beerService = beerService;
    }

    @Operation(summary = "Listar todas as cervejas")
    @GetMapping
    public List<Beer> getAll() {
        return beerService.getAll();
    }

    @Operation(summary = "Buscar cerveja por ID")
    @GetMapping("/{id}")
    public Beer getById(@PathVariable Long id) {
        return beerService.getById(id);
    }

    @Operation(summary = "Buscar cervejas por cervejaria")
    @GetMapping("/brewery/{id}")
    public List<Beer> getByBrewery(@PathVariable Long id) {
        return beerService.getByBrewery(id);
    }

    @Operation(summary = "Criar cerveja")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Beer create(@RequestBody Beer beer) {
        return beerService.create(beer);
    }

    @Operation(summary = "Atualizar cerveja")
    @PutMapping("/{id}")
    public Beer update(@PathVariable Long id, @RequestBody Beer beer) {
        return beerService.update(id, beer);
    }

    @Operation(summary = "Deletar cerveja")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        beerService.delete(id);
    }
}
