package br.com.fiap.beer.repository;

import br.com.fiap.beer.entity.Brewery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BreweryRepository extends JpaRepository<Brewery, Long> {
}
