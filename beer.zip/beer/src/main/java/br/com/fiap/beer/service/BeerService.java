package br.com.fiap.beer.service;

import br.com.fiap.beer.entity.Beer;
import br.com.fiap.beer.repository.BeerRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BeerService {

    private final BeerRepository beerRepository;


    public BeerService(BeerRepository beerRepository) {
        this.beerRepository = beerRepository;
    }

    @Cacheable("beers")
    public List<Beer> getAll() {
        return beerRepository.findAll();
    }

    @Cacheable(value = "beerById", key = "#id")
    public Beer getById(Long id) {
        return beerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Beer not found"));
    }

    @Cacheable(value = "beerByBrewery", key = "#breweryId")
    public List<Beer> getByBrewery(Long breweryId) {
        return beerRepository.findByBreweryId(breweryId);
    }

    @CacheEvict(value = {"beers", "beerById", "beerByBrewery"}, allEntries = true)
    public Beer create(Beer beer) {
        return beerRepository.save(beer);
    }

    @CacheEvict(value = {"beers", "beerById", "beerByBrewery"}, allEntries = true)
    public Beer update(Long id, Beer beer) {
        Beer existing = getById(id);

        existing.setName(beer.getName());
        existing.setDescription(beer.getDescription());
        existing.setAlcoholContent(beer.getAlcoholContent());
        existing.setHarmonization(beer.getHarmonization());
        existing.setBrewery(beer.getBrewery());

        return beerRepository.save(existing);
    }

    @CacheEvict(value = {"beers", "beerById", "beerByBrewery"}, allEntries = true)
    public void delete(Long id) {
        beerRepository.deleteById(id);
    }
}
