package br.com.fiap.beer.controller;

import br.com.fiap.beer.entity.Brewery;
import br.com.fiap.beer.repository.BreweryRepository;
import br.com.fiap.beer.service.BreweryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/breweries")
@Tag(name = "Breweries", description = "Gerenciamento de cervejarias")
public class BreweryController {

    private final BreweryService breweryService;

    public BreweryController(BreweryService breweryService) {
        this.breweryService = breweryService;
    }

    @Operation(summary = "Listar cervejarias")
    @GetMapping
    public List<Brewery> getAll() {
        return breweryService.getAll();
    }

    @Operation(summary = "Buscar cervejaria por ID")
    @GetMapping("/{id}")
    public Brewery getById(@PathVariable Long id) {
        return breweryService.getById(id);
    }

    @Operation(summary = "Criar cervejaria")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Brewery create(@RequestBody Brewery brewery) {
        return breweryService.create(brewery);
    }

    @Operation(summary = "Atualizar cervejaria")
    @PutMapping("/{id}")
    public Brewery update(@PathVariable Long id, @RequestBody Brewery brewery) {
        return breweryService.update(id, brewery);
    }

    @Operation(summary = "Deletar cervejaria")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        breweryService.delete(id);
    }
}
